<?php
$config = array(
  'org_id' => 'zex2jy',
  'port' => '1883',
  'app_id' => 'Internet of Things Platform-nh',
  'iotp_api_key' => 'a-zex2jy-n3mx7qeqx5',
  'iotp_api_secret' => '-hrow(j9XE3GZNLq-n',
  'maps_api_key' => 'GOOGLE-API-KEY',   // for web-app.php only
  'device_id' => '7',
  'qos' => 1,  
  'db_host' => 'DATABASE-HOST-NAME',
  'db_user' => 'DATABASE-USER-NAME',
  'db_pass' => 'DATABASE-USER-PASSWORD',
  'db_name' => 'DATABASE-NAME',
  'wait_time_trigger_min' => 5,         // for webhook-offer.php only
  'proximity_trigger_km' => 1,          // for webhook-offer.php only
);
